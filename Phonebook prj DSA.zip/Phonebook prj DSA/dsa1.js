// Define phonebook array to store contact objects
let phonebook = [];

// Function to add a contact
function addContact() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    
    if (name && phone) {
        phonebook.push({ name, phone });
        alert('Contact added successfully!');
        document.getElementById('addForm').reset();
    } else {
        alert('Please provide both name and phone number.');
    }
}

// Function to search a contact
function searchContact() {
    const searchTerm = document.getElementById('searchTerm').value;
    const result = phonebook.find(contact => contact.name === searchTerm || contact.phone === searchTerm);

    if (result) {
        document.getElementById('searchResult').innerText = `Found: ${result.name} - ${result.phone}`;
    } else {
        document.getElementById('searchResult').innerText = 'Contact not found!';
    }
}

// Function to display all contacts
function displayAllContacts() {
    const contactList = document.getElementById('contactList');
    contactList.innerHTML = ''; // Clear previous contacts

    if (phonebook.length === 0) {
        alert('No contacts available.');
        return;
    }

    phonebook.forEach(contact => {
        const li = document.createElement('li');
        li.innerText = `${contact.name} - ${contact.phone}`;
        contactList.appendChild(li);
    });
}

// Function to delete a contact
function deleteContact() {
    const deleteTerm = document.getElementById('deleteTerm').value;
    const index = phonebook.findIndex(contact => contact.name === deleteTerm || contact.phone === deleteTerm);

    if (index !== -1) {
        phonebook.splice(index, 1);
        document.getElementById('deleteResult').innerText = 'Contact deleted successfully!';
    } else {
        document.getElementById('deleteResult').innerText = 'Contact not found!';
    }
}

// Function to update a contact
function updateContact() {
    const updateTerm = document.getElementById('updateTerm').value;
    const newName = document.getElementById('newName').value;
    const newPhone = document.getElementById('newPhone').value;

    const contact = phonebook.find(contact => contact.name === updateTerm || contact.phone === updateTerm);

    if (contact) {
        if (newName) contact.name = newName;
        if (newPhone) contact.phone = newPhone;

        document.getElementById('updateResult').innerText = 'Contact updated successfully!';
    } else {
        document.getElementById('updateResult').innerText = 'Contact not found!';
    }
}
